(Taken from https://www.food.com/recipe/avocado-smoothie-208399)

Ingredients:
- 1 avocado, pitted and peeled
- 1 very ripe banana, peeled
- 1 cup pineapple-orange juice
- 4 ice cubes

Instructions:
- Combine in blender and mix until there are no ice chunks and there is an overall smooth consistency. It will turn light green.