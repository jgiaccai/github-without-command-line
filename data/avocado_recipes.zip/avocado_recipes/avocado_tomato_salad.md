(Taken from https://www.food.com/recipe/cherry-tomato-avocado-salad-255007)

Ingredients:
- 4 cups avocados, diced medium
- 2 cups grape tomatoes or 2 cups cherry tomatoes
- 2 cups cucumbers, peeled and diced medium
- 1 cup red onion, diced small
- 4 tablespoons fresh cilantro, chopped
- 2 teaspoons fresh garlic, minced
- 2 tablespoons lime juice
- 1/4 cup olive oil
- salt
- fresh black pepper
- bibb lettuce, as desired

Instructions:
- Gently toss ingredients together and serve on a bed of fresh Bibb lettuce.